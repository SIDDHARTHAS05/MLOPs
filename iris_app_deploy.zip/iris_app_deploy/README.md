########## Flask ##############
flask –-app iris_model run


flask run


python iris_model.py

########## Fastapi ##############
fastapi run iris_model.py
